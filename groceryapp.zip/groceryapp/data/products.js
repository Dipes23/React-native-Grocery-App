export let products = [
    {
        "id":1,
        "title":"Orange",
        "desc":"Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
        "image":"orange.png",
        "price":2,
    },
    {
        "id":2,
        "title":"Banana",
        "desc":"Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
        "image":"banana.png",
        "price":3,
    },
]